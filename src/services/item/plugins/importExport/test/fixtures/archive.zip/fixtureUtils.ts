export const FOLDER_PATH = './fixtures/utils';
export const FOLDER_NAME = 'folder';
export const APP_NAME = 'app';
export const DEFAULT_FOLDER_NAME = 'parentFolder';
export const IMAGE_NAME = 'img';
export const IMAGE_NAME_WITHOUT_EXTENSION = 'img_no_extension';
export const LINK_NAME = 'link';
export const DOCUMENT_NAME = 'document';
